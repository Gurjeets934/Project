<!DOCTYPE html>

<?php $__env->startSection('content'); ?>
<body>
<div class="container">
<div class="row">
<div class="col-md-1">
</div>
<div class="col-md-10">

<?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card border-2" style="width: 30rem; margin-top:40px; margin-left:200px; background-color:#F8C471 ">
        <div class="card-body">
          <h2 class="heading"><b><i><center>Edit Profile</center></i></b></h2>
          <br>
          <form action="/updateprofile" method="POST"> 
            <?php echo csrf_field(); ?>    
    <!--Input to Edit Profile  -->
    <input type="hidden" name="id" value="<?php echo e($user->id); ?>"><br>
<!-- Input 1 -->
<div class="input-group"><span class="input-group-addon"><p style="font-family:Arial; "><b><i>Your Name&nbsp;</i></b></p></span>
<input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control"></div><br>
<!-- Input 2 -->
<div class="input-group"><span class="input-group-addon"><p style="font-family:Arial "><b><i>Your Email&nbsp;</i></b></p></span>
<input type="text" name="email" value="<?php echo e($user->email); ?>" class="form-control"></div><br>
<!-- Input 3 -->
<div class="input-group"><span class="input-group-addon"><b><i>Your Role&nbsp;&nbsp;</i></b></span>
   <select name="role" style="width:200px; margin-left:30px;">
      <option value="<?php echo e($user->role); ?>" selected><?php echo e($user->role); ?></option>
      <option value="writer">Change to writer</option>
      <option value="editor">Change to editor</option>
   </select>
   </div><br/>
    <!-- End of Inputs -->
    <center><button type="submit" name="btn" class="btn btn-sm btn-info ">submit</button></center><br/>
    
    </form>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
     </div>
     </div>
     </div>
     <?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gurjeet Singh\Desktop\Laravel-Blog-Project-main\resources\views/editprofile.blade.php ENDPATH**/ ?>