<!DOCTYPE html>

<?php $__env->startSection('content'); ?>
<body>
<div class="container">
<div class="row">
<div class="col-md-1">
</div>
<div class="col-md-10">

<?php $__currentLoopData = $profile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card border-2" style="width: 30rem; margin-top:40px; margin-left:200px; background-color:#F9E79F ">
        <div class="card-body">
          <h2 class="heading"><b><i><center>My Profile</center></i></b></h2>
          <br>
    <p style="font-family:Arial "><b><i>Your Name</i></b> - &nbsp;<?php echo e($user->name); ?></p>
    <p style="font-family:Arial;  "><b><i>Your Email</i></b> - &nbsp;<?php echo e($user->email); ?></p>   
    <p style="font-family:Arial;  "><b><i>Your Role</i></b> - &nbsp; <?php echo e($user->role); ?></p>

   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
     </div>
     </div>
     </div>
     <?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gurjeet Singh\Desktop\Laravel-Blog-Project-main\resources\views/myprofile.blade.php ENDPATH**/ ?>