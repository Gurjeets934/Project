<!DOCTYPE html>

<html lang="en">
<?php echo $__env->yieldContent('content'); ?>
<head>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
    /* The sidebar menu */
.sidenav {
  height: 100%; /* Full-height: remove this if you want "auto" height */
  width: 200px; /* Set the width of the sidebar */
  position: fixed; /* Fixed Sidebar (stay in place on scroll) */
  z-index: 1; /* Stay on top */
  top: 0; /* Stay at the top */
  left: 0;
  background-color: #e8ecef; /* Black */
  overflow-x: hidden; /* Disable horizontal scroll */
  padding-top: 20px;
}

/* The navigation menu links */
.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color:black;
  display: block;
}

/* When you mouse over the navigation links, change their color */
.sidenav a:hover {
  color: #818181;
  text-decoration: none;
}
/* Changes font size to custom size */
.s
{
  font-size: 20px;
}

/* On smaller screens, where height is less than 450px, change the style of the sidebar (less padding and a smaller font size) */
@media  screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
    </style>
    <link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css">
    <title>Blogger</title>
</head>
<body>

<div class="sidenav">
<h5 style="margin-left:20px;">Welcome,<?php echo e(session('user')); ?></h5>  
<a href="/home" style="color:orange">Blogger</a>
   
  <hr size="5" color="#f9f3f3">
  <a href="/dashboard" style="font-size:20px">Dashboard</a>
  <?php 
  if(session()->has('role'))
  {if(session('role')=='editor')
  {
    echo "<a href='/showposts' style='font-size:20px'>Show Posts</a>";
  }
  if(session('role')=='writer')
  {
    
  ?>
   
  <a href="/aposts" style="font-size:20px">Add Posts</a>
  <a href="/vposts" style="font-size:20px">View Posts</a>
  <?php }
  }
  ?>
  <a href="/myprofile" style="font-size:20px">My Profile</a>
  <a href="/editprofile" style="font-size:20px"> Edit Profile</a>
  <a href="/logout" style="font-size:20px">Log Out</a>
</div>
    
<?php /**PATH C:\Users\Gurjeet Singh\Desktop\Laravel-Blog-Project-main\resources\views/sidebar.blade.php ENDPATH**/ ?>