<!DOCTYPE html>
@extends('sidebar')
@section('content')
<body>
<div class="container">
<div class="row">
<div class="col-md-1">
</div>
<div class="col-md-10">

@foreach($profile as $user)
<div class="card border-2" style="width: 30rem; margin-top:40px; margin-left:200px; background-color:#F8C471 ">
        <div class="card-body">
          <h2 class="heading"><b><i><center>Edit Profile</center></i></b></h2>
          <br>
          <form action="/updateprofile" method="POST"> 
            @csrf    
    <!--Input to Edit Profile  -->
    <input type="hidden" name="id" value="{{$user->id}}"><br>
<!-- Input 1 -->
<div class="input-group"><span class="input-group-addon"><p style="font-family:Arial; "><b><i>Your Name&nbsp;</i></b></p></span>
<input type="text" name="name" value="{{$user->name}}" class="form-control"></div><br>
<!-- Input 2 -->
<div class="input-group"><span class="input-group-addon"><p style="font-family:Arial "><b><i>Your Email&nbsp;</i></b></p></span>
<input type="text" name="email" value="{{$user->email}}" class="form-control"></div><br>
<!-- Input 3 -->
<div class="input-group"><span class="input-group-addon"><b><i>Your Role&nbsp;&nbsp;</i></b></span>
   <select name="role" style="width:200px; margin-left:30px;">
      <option value="{{$user->role}}" selected>{{$user->role}}</option>
      <option value="writer">Change to writer</option>
      <option value="editor">Change to editor</option>
   </select>
   </div><br/>
    <!-- End of Inputs -->
    <center><button type="submit" name="btn" class="btn btn-sm btn-info ">submit</button></center><br/>
    
    </form>
   @endforeach
</div>
     </div>
     </div>
     </div>
     @stop
</body>
</html>
