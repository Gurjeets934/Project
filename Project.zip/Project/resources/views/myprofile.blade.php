<!DOCTYPE html>
@extends('sidebar')
@section('content')
<body>
<div class="container">
<div class="row">
<div class="col-md-1">
</div>
<div class="col-md-10">

@foreach($profile as $user)
<div class="card border-2" style="width: 30rem; margin-top:40px; margin-left:200px; background-color:#F9E79F ">
        <div class="card-body">
          <h2 class="heading"><b><i><center>My Profile</center></i></b></h2>
          <br>
    <p style="font-family:Arial "><b><i>Your Name</i></b> - &nbsp;{{$user->name}}</p>
    <p style="font-family:Arial;  "><b><i>Your Email</i></b> - &nbsp;{{$user->email}}</p>   
    <p style="font-family:Arial;  "><b><i>Your Role</i></b> - &nbsp; {{$user->role}}</p>

   @endforeach
</div>
     </div>
     </div>
     </div>
     @stop
</body>
</html>
