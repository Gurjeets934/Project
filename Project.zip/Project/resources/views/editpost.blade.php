@extends('sidebar')
@section('content')
<head>
<link href="/bootstrap/bootstrap.min.css" rel="stylesheet"/>
</head>
<body>
<div class="container-md" style="overflow-x:hidden">
<div class="row">
<div class="col-md-3">
</div>

<div class="col-md-6">
<div class="jumbotron" style="margin-top:50px; height:480px">
    <h1 style="font-family:Algerian Regular;"><center>EDIT YOUR POST</center></h1><br>

    <form action="/updatepost" method="POST">
        @csrf
        <input type="hidden" name="id" value="{{$posts->id}}"><br>
        
        <div class="input-group"><span class="input-group-addon">TITLE</span>
        <input type="text" name="title" value="{{$posts->title}}" class="form-control"></div><br>

          @error('title')
          <center><span style="color:red;">{{ $message }}</span></center>
          @enderror
          

        <div class="input-group"><span class="input-group-addon">DESCRIPTION</span>
        <textarea name="body"  cols="100" rows="5" class="form-control">{{$posts->body}}</textarea></div><br>

        @error('body')
          <center><span style="color:red;">{{ $message }}</span></center>
          @enderror
          

        <button class="btn btn-block btn-info" type="submit" name="btn">UPDATE</button><br>
    </form>
</div>
</div>
<div class="col-md-3">
</div>
</div>
</div>
@stop
</body>
</html>