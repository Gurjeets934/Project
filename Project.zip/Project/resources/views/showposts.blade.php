<!DOCTYPE html>
@extends('sidebar')
@section('content')
<body style="background-color:#F7DC6F;">

<!-- Posts -->

<section style=" margin:100px;" id="blog">
<h2 style="color:#9A7D0A; margin-top:-50px; margin-left:200px"><center>All Blogs</center></h2>
<br>
  <div class="row">
    
    <?php 

    function custom_echo($x, $length)
    {
      if(strlen($x)<=$length)
      {
        echo "<p class='card-text'>$x</p>";
      }
      else
      {
        $y=substr($x,0,$length) . '...';
        echo "<p class='card-text'>$y</p>";
      }
    }  
    ?>
  
  @foreach($posts as $post)
  <div class="col-lg-2 ">
  </div>
    <div class="col-lg-2 ">
      <div class="card border-2" style="width: 23rem; margin-top:10px; background-color:#F9E79F ">
        <div class="card-body">
          <h2 class="heading"><b>{{$post->title}}</b></h2>
        
<!-- Function to output summary of body -->

<?php 
custom_echo($post->body,20);
?>
<a href="/vposts/{{$post->id}}" style="text-decoration:none;">📝Cick to see post</a>
        </div>
        </div>
        </div>
      <div class="col-lg-2">
      </div>
      @endforeach
    </div>
 
</section>

@stop
  </body>
</html>
