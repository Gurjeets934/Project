<!DOCTYPE html>
@extends('sidebar')
@section('content')

<style>
    .l{
       height:300px; width:600px; float:left; background-color:#413c69; padding:90px 20px 20px 20px; color:#f9f3f3; margin-left:100px;
       display:flex; 
    }
    .r{
        height:300px; width:600px;  float:right; background-color:#413c69; padding:20px 20px 20px 20px; color:#f9f3f3; margin-right:400px;
        display:flex; 
    }
    
    .li{
        height:300px; width:600px; float:left; background-color:#822659; padding:90px 20px 20px 20px; color:#f9f3f3; margin-left:100px;
        margin-top:30px; 

    }

    .ri{
        height:300px; width:600px;  float:right; background-color:#822659; padding:20px 20px 20px 20px; color:#f9f3f3; margin-right:400px;
        margin-top:30px; 
    }

    </style>
</head>
<body>
<div class="row">
<div class="col-md-1">
</div>
<div class="col-md-11">
<center><div  style="height:100px; width:500px; margin-left:50px; margin-top:50px; margin-bottom:20px; color:#f875aa;  padding:20px 20px 20px 20px; background-color:#f4f9f9; float=left">
    <h1 style='font-family:Berlin Sans FB'><center>Blog Your First Blog </center></h1></div>
    <h4><center>Welcome to Blogger</center></h4>
    
    
    <h5><center>Here we blog! </center></h5><br>
            
</div></center>
</div>
</div>
   
    @stop
    </body>
    </html>