<!DOCTYPE html>
@extends('sidebar')
@section('content')
<body>
<div class="container">
<div class="row">
<div class="col-md-2">
</div>
<div class="col-md-8">

<div style="background-color:#e3d18a; height:100%; width:100%; color:#ff1500; margin-top:40px; margin-left:100px; padding:50px 50px 50px 50px">
@foreach($posts as $post)
    <h1 style="font-family:Blackadder ITC Regular"><center>{{$post->title}}</center></h1>
    <h6>Added By:<p style="font-family:Algerian Regular; font-size:15px; ">{{$post->name}}</p></h6>
    <br>
    
    
    <p style="font-family:Arial; font-size:15px; ">{{$post->body}}</p>     

   @endforeach


    </div>
     </div>
     <div class="col-md-2">
</div>
     </div>

     <?php
     
        if(session('role')=='writer')
        { 
            ?>
            <div class="row">
<div class="col-md-4">
</div>
<div class="col-md-7">
<div class="container"   style="padding:20px 20px 20px 20px; border:#404040 3px dotted; width:100%;  margin-top:70px; margin-bottom:70px">
<h5 style=' color:blue'><center>Comments Section!</center></h5>
@foreach($comments as $comment)
<p style='color: #686868; border:red 2px dashed'>{{$comment->comment}}-<i>commented by</i>  <b>{{$comment->sender}}</b></p>
            @endforeach        
            <?php
        }?>
        </div>
        </div>  
        <div class="col-md-1">
        </div>
        </div>  
        <?php
        

        if(session('role')=='editor')
        {
        
     ?>
     <form action="addcomment" method="post">    
    @csrf
    @foreach($posts as $post)
    <center><div class="input-group" style="width:50%; margin-top:70px; margin-left:180px ">
    <input type="text" name="comment" class="form-control" placeholder="Enter Your Comment Here!"/>
    <input type="hidden" name="reciever" value="{{$post->name}}">
    <input type="hidden" name="postid" value="{{$post->id}}">
    <span class="input-group-addon"><button type="submit" name="btn" class="btn btn-block btn-primary ">Add</button></span>    
</div></center>
@endforeach
</form>
<?php
        }
    ?>
<?php
     if(session('role')=='editor')
     { 
 ?>
 <div class="row">
<div class="col-md-4">
</div>
<div class="col-md-6">
<div class="container"   style="padding:20px 20px 20px 20px; border:#404040 3px dotted; width:100%;  margin-top:70px; margin-bottom:70px">
<h5 style=' color:blue'><center>Your Comments!</center></h5>
@foreach($mycomment as $mycomment)
<p style='color: #686868; border:red 2px dashed'>{{$mycomment->comment}}</p>
            @endforeach        
            <?php
        }?>
        </div>
        </div>  
        <div class="col-md-1">
        </div>
        </div>  
@stop
</body>
</html>
