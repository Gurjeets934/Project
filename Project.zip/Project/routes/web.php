<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\dbcontroller;
use App\Http\Controllers\postcontroller;
Route::get('/welcome', function () {return view('welcome');});

Route::get('/', function () {return view('home');});

Route::view('home','home');

Route::view('register','register');

Route::view('login','login');

Route::post('registeruser',[dbcontroller::class,'registeruser']);

Route::post('loginuser',[dbcontroller::class,'loginuser']);

Route::get('logout', function(){
    session()->forget('user');
    session()->forget('role');
    return redirect('home');
});

Route::get('myprofile',[dbcontroller::class,'myprofile']);

Route::get('editprofile',[dbcontroller::class,'editprofile']);

Route::post('updateprofile',[dbcontroller::class,'updateprofile']);

Route::view('forgetpass','forgetpass');

Route::post('updatepass',[dbcontroller::class,'updatepass']);

Route::view('showposts','showposts');

Route::get('showposts',[postcontroller::class,'showposts']);

Route::get('dashboard',[postcontroller::class,'dashboard']);

Route::view('aposts','aposts');

Route::post('addposts',[postcontroller::class,'addpost']);


Route::get('vposts', [postcontroller::class, 'allposts']);

Route::get('vposts/{id}', [postcontroller::class, 'viewposts']);

Route::post('vposts/addcomment',[postcontroller::class, 'addcomment']);

Route::view('viewposts','viewposts');



Route::get('/editpost/{id}', [postController::class, 'editpost']);

Route::post('updatepost', [postcontroller::class, 'updatepost']);

Route::get('deletepost/{id}',[postcontroller::class,'deletepost']);
