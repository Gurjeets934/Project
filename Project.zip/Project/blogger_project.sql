-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2022 at 05:50 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogger_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(20) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  `sender` varchar(200) NOT NULL,
  `reciever` varchar(200) NOT NULL,
  `postid` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `comment`, `sender`, `reciever`, `postid`) VALUES
(1, 'This is the first comment', 'Doraemon', 'Jack Jones', '1'),
(2, 'HI cOMMENT', 'Doraemon', 'Jack Jones', '3'),
(3, 'I am adding a comment!!!', 'Doraemon', 'Jack Jones', '5'),
(4, 'I love this movie! It is of marvel and science fiction containing all the heroic and the marvel stuff they put into every movie', 'amar', 'Gurjeet Singh', '12'),
(5, 'This is one of the best marvel movies', 'amar', 'Gurjeet Singh', '12'),
(6, 'This is one comment only one not two only one', 'amar', 'Paul James', '6'),
(7, 'What a blog! I really liked it!!', 'Doraemon', 'Mik', '7'),
(8, 'I love this blog it is vey neice kjsdm kl I love this blog it is vey neice kjsdm kl', 'Doraemon', 'Gurjeet Singh', '12'),
(9, 'A good blog to see! Thanks for posting................', 'Doraemon', 'Mik', '7'),
(10, 'Thanks for the information! we will take care about it.', 'amar', 'example', '13');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(20) NOT NULL,
  `title` varchar(200) NOT NULL,
  `body` varchar(2500) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `body`, `name`) VALUES
(1, 'My New Blog', 'This is the Blog', 'Jack Jones'),
(3, 'MY BLOG 23', 'The Blog is the Best Page for Creating Blogs like this one.', 'Jack Jones'),
(5, 'OUR UNIVERSITY', 'OUR UNIVERSITY NAME IS LOVELY PROFESSIONAL UNIVERSITY.I AM STUDENT OF IT.', 'Paul James'),
(6, 'MY SCHOOL', 'MY SCHOOL HAS 20 ROOMS. 50 TEACHERS. 1 PRINCIPAL. 3000 STUDENTS.', 'Paul James'),
(7, 'LOVE YOURSELF', 'LOVE YOURSELF IS THE BIGGEST THING A PERSON CAN DO. LOVING YOURSELF IS THE KEY TO THE HEART OF THE BODY YOU ARE IN WHICH NOBODY HAS RIGHT NOW. THE MORE YOU KNOW MORE YOU GET BETTER ABOUT HEART. THE LOVE IS THE ANSWER TO THE JOURNEY THAT YOU ARE IN THIS MYSTERIOUS WORLD OF UNKNOWING', 'Mik'),
(9, 'SAVE WATER', 'SAVE WATER IN THE WORLD.', 'Paul James'),
(12, 'Guardians of Galaxy', 'Guardians of Galaxy is the biggest adventure and action movie genre: action, adventures', 'Gurjeet Singh'),
(13, 'example post', 'example posts description , it contains all the description of the blog or post user wants to add. It is very important to write correctly as it will show to all the users once posted. Although, it can be edited afterwards, still user should be careful while adding their information.', 'example');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id` int(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(20) NOT NULL,
  `role` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `name`, `email`, `password`, `role`) VALUES
(1, 'Jack Jones', 'jackjones@gmail.com', 'Int221@', 'writer'),
(3, 'Doraemon', 'doraemon@gmail.com', 'Int221@', 'editor'),
(4, 'Paul James', 'pauljames@gmail.com', 'Int221@', 'writer'),
(5, 'Tancy ', 'tancy@gmail.com', 'Int221@', 'editor'),
(6, 'Nobita', 'nobita@gmail.com', 'Int221@', 'editor'),
(7, 'Jarvis Two Point Zero', 'jarvis2@stark.co.in', 'Jarvis2!', 'editor'),
(8, 'Sansa Stark', 'sansastark@gmail.com', 'Int221@', 'editor'),
(10, 'Mik', 'mike@gmail.com', 'Int221@', 'writer'),
(11, 'XYZ', 'xyz@gmail.com', 'Int221@', 'editor'),
(13, 'abc', 'abc@gmail.com', 'Int221@', 'editor'),
(14, 'Gurjeet Singh', 'gurjeets202@gmail.com', 'LetmePas@', 'writer'),
(17, 'amar', 'abc@xyz.com', 'Amar2@', 'editor'),
(18, 'example', 'example1@email.com', 'Exampass2@', 'writer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
