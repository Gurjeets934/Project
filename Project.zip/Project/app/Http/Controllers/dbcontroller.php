<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class dbcontroller extends Controller
{

    function registeruser(Request $req)
 {
    $req->validate([
        'name'=>'required|regex:/^[a-zA-Z ]+$/',
        'email'=>'required|regex:/^[a-z]{2,}[.]?[0-9]*@[a-z]+[.][a-z]{2,3}(.[a-z]{2})?$/',
        'password'=>'required|regex:/^(?=.*[0-9])(?=.*[A-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]*$/',
        'cpassword'=>'required|same:password',
    ]);
    
    
    $data = array(
        'name'=>$req->name,
        'email'=>$req->email,
        'password'=>$req->password,
        'role'=>$req->role,
        );
        DB::table('signup')->insert($data);
        
        return redirect('login');    
 }

  function loginuser(Request $request)
  {
    $users = DB::table('signup')->get();
    $flag=0;
        foreach ($users as $user) {
                $name=$user->name;
                $password=$user->password;
                

        if(($name==$request->input('name'))&&($password==$request->input('password')))
        {          
            $role=$user->role;
            $request->session()->put('user',$request->input('name'));
            $request->session()->put('role',$role);
   
            if($request->session()->has('user'))
            {
                return redirect('dashboard');
            }
            
            $flag=1;
            break;
         }  
        else
        { 

        $flag=2;
        }  
    }

    if($flag==2)
    {
        echo "<script>
        alert('Invalid Username and Password');
        window.location='login';
     </script>";
    }
}
public function updatepass(Request $req)
{   
    
    DB::table('signup')->where('name',$req->name)->update([
        'password'=>$req->password,
    ]);
    echo "<script>
    alert('Password Changed Successfully');
    window.location='login';
 </script>";
}
public function myprofile()
    {   
        $profile = DB::table('signup')->get()->where('name',session('user'));
        return view('myprofile', compact('profile'));
    }

public function editprofile()
    {
        $profile = DB::table('signup')->get()->where('name',session('user'));
        return view('editprofile', compact('profile'));
    }

    public function updateprofile(Request $req)
    {
       

        DB::table('signup')->where('id',$req->id)->update([
            'name'=>$req->name,
            'email'=>$req->email,
            'role'=>$req->role,
        ]);
        DB::table('posts')->where('name',session('user'))->update([
            'name'=>$req->name,
        ]);
        DB::table('comments')->where('reciever',session('user'))->update([
            'reciever'=>$req->name,
        ]);

        if(session()->has('user'))
        {
            $req->session()->put('user',$req->name);
        }

        echo "<script>
        alert('Profile Updated Successfully');
        window.location='myprofile';
     </script>";

        
    
    }

}

